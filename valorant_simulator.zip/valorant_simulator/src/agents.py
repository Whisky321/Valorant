from abc import ABC, abstractmethod
from typing import List


class Agent(ABC):
    def __init__(self, name: str, role_type: str, health: int = 100):
        self.name = name
        self.role_type = role_type
        self.health = health
        self.abilities = []

    @abstractmethod
    def use_ultimate(self) -> str:
        pass

    def take_damage(self, damage: int) -> None:
        self.health = max(0, self.health - damage)
        if self.health == 0:
            print(f"{self.name} 已被击败！")

    def heal(self, amount: int) -> None:
        self.health = min(100, self.health + amount)


class Duelist(Agent):
    def __init__(self, name: str):
        super().__init__(name, "Duelist")
        self.abilities = ["闪现", "近战攻击", "突进"]

    def use_ultimate(self) -> str:
        return f"{self.name} 使用终极技能: 无双斩！"


class Sentinel(Agent):
    def __init__(self, name: str):
        super().__init__(name, "Sentinel")
        self.abilities = ["陷阱", "护盾", "侦查"]

    def use_ultimate(self) -> str:
        return f"{self.name} 使用终极技能: 全方位防御！"


class Controller(Agent):
    def __init__(self, name: str):
        super().__init__(name, "Controller")
        self.speed = 5  # 控制器角色的移动速度
        self.abilities = ["区域封锁", "信息收集", "地形控制"]


class Initiator(Agent):
    def __init__(self, name: str):
        super().__init__(name, "Initiator")
        self.speed = 5  # 先锋角色的移动速度
        self.abilities = ["侦察", "突进", "干扰"]


class Viper(Controller):
    def __init__(self):
        super().__init__("蝰蛇")
        self.country = "美国"
        self.abilities = ["毒云", "蛇咬", "毒气陷阱", "致命毒雾"]
        self.weapon = "毒雾喷射器"
        self.poison_clouds = []

    def use_ability(self, ability_index: int) -> str:
        if ability_index == 0:  # 毒云
            self.poison_clouds.append({"duration": 10, "damage": 5})
            return f"{self.name} 在目标区域部署了一片毒云！"
        return f"{self.name} 未知技能索引: {ability_index}"

    def use_ultimate(self) -> str:
        self.poison_clouds = []  # 清空现有毒云
        return f"{self.name} 使用终极技能 [{self.abilities[3]}] - 释放大范围致命毒雾！"


class Reyna(Duelist):
    def __init__(self):
        super().__init__("雷兹")
        self.country = "墨西哥"
        self.abilities = ["魅魂", "亡魂", "回魂", "猎杀时刻"]
        self.weapon = "灵魂收割者"
        self.souls_collected = 0

    def take_damage(self, damage: int) -> None:
        super().take_damage(damage)
        if damage > 0 and self.health > 0:
            self.souls_collected += 1
            print(f"{self.name} 收集了 1 个灵魂！当前: {self.souls_collected}")

    def use_ultimate(self) -> str:
        if self.souls_collected >= 3:
            self.souls_collected = 0
            return f"{self.name} 使用终极技能 [{self.abilities[3]}] - 进入猎杀时刻，获得无敌和高伤害！"
        return f"{self.name} 灵魂不足，需要至少 3 个灵魂 ({self.souls_collected}/3)"


class Breach(Initiator):
    def __init__(self):
        super().__init__("铁臂")
        self.country = "瑞典"
        self.abilities = ["闪光爆破", "震荡波", "分裂尖刺", "大地崩坏"]
        self.weapon = "动能冲击器"
        self.charge_level = 0

    def use_ability(self, ability_index: int) -> str:
        if ability_index == 2:  # 分裂尖刺
            if self.charge_level >= 2:
                self.charge_level = 0
                return f"{self.name} 使用 [{self.abilities[ability_index]}] - 发射穿透性尖刺！"
            else:
                self.charge_level += 1
                return f"{self.name} 正在充能分裂尖刺 ({self.charge_level}/2)"
        return f"{self.name} 未知技能索引: {ability_index}"

    def use_ultimate(self) -> str:
        if self.charge_level >= 3:
            self.charge_level = 0
            return f"{self.name} 使用终极技能 [{self.abilities[3]}] - 引发巨大地震，眩晕所有敌人！"
        return f"{self.name} 充能不足，需要至少 3 级 ({self.charge_level}/3)"


class Jett(Duelist):
    def __init__(self):
        super().__init__("捷特")
        self.country = "韩国"

    def use_ultimate(self) -> str:
        return f"{self.name} 使用终极技能: 刀锋风暴！"


class Phoenix(Duelist):
    def __init__(self):
        super().__init__("火男")
        self.country = "英国"

    def use_ultimate(self) -> str:
        return f"{self.name} 使用终极技能: 烈火新星！"


class Sage(Sentinel):
    def __init__(self):
        super().__init__("贤者")
        self.country = "中国"

    def use_ultimate(self) -> str:
        return f"{self.name} 使用终极技能: 复活术！"