from typing import List
from src.agents import Agent
from src.map import Map


class GameState:
    def __init__(self):
        self.round = 1
        self.attacking_team: List[Agent] = []
        self.defending_team: List[Agent] = []
        self.map: Map | None = None
        self.bomb_planted = False
        self.bomb_site = None
        self.bomb_timer = 0

    def start_round(self, map_name: str, sites: List[str]) -> None:
        self.map = Map(map_name, sites)
        self.bomb_planted = False
        self.bomb_site = None
        self.bomb_timer = 45  # 45秒炸弹计时器
        print(f"\n=== 第 {self.round} 回合开始 ===")
        print(f"地图: {map_name}")
        print(f"攻击方: {', '.join(a.name for a in self.attacking_team)}")
        print(f"防守方: {', '.join(a.name for a in self.defending_team)}")

    def plant_bomb(self, planter: Agent, site: str) -> bool:
        if self.map and site in self.map.sites and not self.bomb_planted:
            self.bomb_planted = True
            self.bomb_site = site
            print(f"\n{planter.name} 在 {site} 点安装了炸弹！")
            print(f"炸弹将在 {self.bomb_timer} 秒后爆炸")
            return True
        return False

    def defuse_bomb(self, defuser: Agent) -> bool:
        if self.bomb_planted:
            print(f"\n{defuser.name} 正在拆除炸弹！")
            self.bomb_planted = False
            print(f"{defuser.name} 成功拆除了炸弹！")
            return True
        return False

    def update(self) -> None:
        if self.bomb_planted:
            self.bomb_timer -= 1
            if self.bomb_timer <= 0:
                print("\n炸弹爆炸！攻击方胜利！")
                self.round += 1
                if self.map:
                    self.start_round(self.map.name, self.map.sites)