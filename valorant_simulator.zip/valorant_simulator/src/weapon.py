class Weapon:
    def __init__(self, name: str, damage: int, fire_rate: float, magazine_size: int):
        self.name = name
        self.damage = damage
        self.fire_rate = fire_rate
        self.magazine_size = magazine_size
        self.current_ammo = magazine_size

    def shoot(self) -> str:
        if self.current_ammo > 0:
            self.current_ammo -= 1
            return f"使用 {self.name} 射击，造成 {self.damage} 点伤害！"
        return f"{self.name} 弹夹为空，正在换弹..."

    def reload(self) -> None:
        self.current_ammo = self.magazine_size
        print(f"{self.name} 换弹完成！")