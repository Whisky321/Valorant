from typing import Dict, Type, List
from src.agents import Agent, Jett, Phoenix, Sage, Viper, Reyna, Breach


class AgentFactory:
    _agents: Dict[str, Type[Agent]] = {
        "jett": Jett,
        "phoenix": Phoenix,
        "sage": Sage,
        "viper": Viper,
        "reyna": Reyna,
        "breach": Breach
    }

    @staticmethod
    def create_agent(agent_type: str) -> Agent:
        if agent_type.lower() not in AgentFactory._agents:
            raise ValueError(f"未知角色类型: {agent_type}")
        return AgentFactory._agents[agent_type.lower()]()

    @staticmethod
    def get_available_agents() -> List[str]:
        return list(AgentFactory._agents.keys())