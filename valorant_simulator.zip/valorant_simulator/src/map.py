from typing import List, Dict
from src.agents import Agent  # 导入Agent类用于类型注解


class Map:
    def __init__(self, name: str, sites: List[str]):
        self.name = name
        self.sites = sites
        self.blockers = []  # 障碍物、毒云等

    def add_blocker(self, agent: Agent, ability_name: str, duration: int) -> str:
        self.blockers.append({
            "agent": agent.name,
            "ability": ability_name,
            "duration": duration
        })
        return f"{agent.name} 在 {self.name} 上使用 {ability_name} 设置了障碍物！"

    def remove_expired_blockers(self) -> None:
        self.blockers = [b for b in self.blockers if b["duration"] > 0]
        for b in self.blockers:
            b["duration"] -= 1