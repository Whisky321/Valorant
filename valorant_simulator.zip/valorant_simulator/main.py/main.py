from src.agent_factory import AgentFactory
from src.game_state import GameState
from src.weapon import Weapon


def main():
    # 1. 使用工厂创建角色
    print("可用角色:", AgentFactory.get_available_agents())
    reyna = AgentFactory.create_agent("reyna")
    viper = AgentFactory.create_agent("viper")
    sage = AgentFactory.create_agent("sage")
    jett = AgentFactory.create_agent("jett")

    # 2. 初始化武器并测试
    print("\n--- 武器测试 ---")
    rifle = Weapon("幻影步枪", 15, 0.1, 30)
    print(rifle.shoot())
    print(rifle.shoot())
    rifle.reload()

    # 3. 初始化游戏状态并开始回合
    print("\n--- 游戏流程测试 ---")
    game = GameState()
    game.attacking_team = [reyna, jett]  # 攻击方
    game.defending_team = [viper, sage]  # 防守方
    game.start_round("炼狱小镇", ["A点", "B点"])  # 开始回合（地图：炼狱小镇，炸弹点A/B）

    # 4. 测试角色技能
    print("\n--- 技能测试 ---")
    print(reyna.use_ultimate())  # 雷兹初始灵魂不足
    reyna.take_damage(20)  # 受伤害收集灵魂
    reyna.take_damage(30)
    reyna.take_damage(10)
    print(reyna.use_ultimate())  # 灵魂足够，释放终极技能
    print(viper.use_ability(0))  # 蝰蛇使用毒云
    print(viper.use_ultimate())  # 蝰蛇释放终极技能
    print(sage.use_ultimate())   # 贤者释放复活术

    # 5. 测试炸弹机制
    print("\n--- 炸弹测试 ---")
    game.plant_bomb(reyna, "A点")  # 雷兹在A点下包
    game.defuse_bomb(sage)  # 贤者拆包


if __name__ == "__main__":
    main()